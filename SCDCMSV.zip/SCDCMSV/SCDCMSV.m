clear;
addpath('tSVD','proxFunctions','solvers','twist','data');
addpath('ClusteringMeasure', 'LRR', 'Nuclear_norm_l21_Algorithm', 'unlocbox');


load('bbcsport.mat');

gt = Y ;
cls_num = length(unique(gt));
%% Note: each column is an sample (same as in LRR)
%% 
%data preparation...
 for v=1:2
    [X{v}]=NormalizeData(X{v}');
 end

% Initialize...
K = length(X); N = size(X{1},2); %sample number

lambda1 = 0.1;
lambda2 = 10;
lambda3 = 0.0001;

Isconverg = 0;epson = 1e-7;
iter = 0;
mu1 = 10e-4; max_mu1 = 10e12; pho_mu1 = 2;
mu2 = 10e-4; max_mu2 = 10e12; pho_mu2 = 2;
rho1 = 0.0001; max_rho1 = 10e12; pho_rho1 = 2;
rho2 = 0.0001; max_rho2 = 10e12; pho_rho2 = 2;
tic;
%-------------------------------
for k=1:K
    Z{k} = zeros(N,N); 
    E1{k} = zeros(size(X{k},1),N); 
    Y1{k} = zeros(size(X{k},1),N); 
end

for a=1:2
    W{a} = zeros(N,N);
    G{a} = zeros(N,N);
end

S = zeros(N);
C=zeros(N,N);
E=zeros(N);
Q=zeros(N,N);

w = zeros(N*N*2,1);
g = zeros(N*N*2,1);
Y2=zeros(N,N);
Y3=zeros(N);
dim1 = N;dim2 = N;dim3 = 2;
myNorm = 'tSVD_1';
sX = [N, N, 2];
%--------------------------------
while(Isconverg == 0)
%     fprintf('----processing iter %d--------\n', iter+1);
    for k=1:K % K=3
        %1 update Z^k        
        tmp1 = X{k}'*Y1{k} + mu1*X{k}'*X{k} - mu1*X{k}'*X{k}*S - mu1*X{k}'*E1{k};
        Z{k}=pinv(mu1*X{k}'*X{k}+lambda2*eye(N,N)+lambda2*eye(N,N))*tmp1;
    end
        %2 updateC--2
        tmp2=S'*Y2 + mu2*S'*S - mu2*S'*E - W{2} + rho1*G{2};
%         C=inv(mu2*S'*S+rho1*eye(N))*tmp2;
tC = pinv(mu2*S'*S+rho1*eye(N));
        C=tC*tmp2;
tSl=0; tSa1=0;tSa2=0;
for k=1:K
    tSl = tSl + X{k}'*X{k}; 
    tSa1 = tSa1 + X{k}'*Y1{k};
    tSa2 = tSa2 + X{k}'*X{k}-X{k}'*X{k}*Z{k}-X{k}'*E1{k};
end
S_left = mu1*tSl + mu2*eye(N) + rho2*eye(N) + rho1*eye(N);
S_right = mu2*C*C' - mu2*C - mu2*C';
S_all = tSa1 + mu1*tSa2 -Y2+Y2*C' + mu2*E - mu2*E*C' - Y3+rho2*Q-W{1}+rho1*G{1};
S = lyap(S_left,S_right,S_all);

for k=1:K
        %4 update E^k v=1,2,...,V
        tmp3=Y1{k}+mu1*X{k}-mu1*X{k}*S-mu1*X{k}*Z{k};
        E1{k}=tmp3*pinv(mu1*eye(N,N)+lambda3*eye(N,N)+lambda3*eye(N,N));
end
%       update E   v=V+1
        tmp4 = Y2+mu2*S-mu2*S*C;
        tmp5 = pinv(mu2*eye(N,N)+lambda3*eye(N,N)+lambda3*eye(N,N));
        E = tmp4*tmp5;
%     end

      
    %5 update G
    H_tensor = cat(3, S, C);
    W_tensor = cat(3, W{:,:});
    h = H_tensor(:);
    w = W_tensor(:);  
    [g, objV] = wshrinkObj(h + 1/rho1*w,lambda1/rho1,sX,0,3)   ;
    G_tensor = reshape(g, sX);

%   6 update Q
    temp = S + Y3/rho2;
    [U,sigma,V] = svd(temp,'econ');
    sigma = diag(sigma);
    svp = length(find(sigma>1/rho2));
    if svp>=1
        sigma = sigma(1:svp)-1/rho2;
    else
        svp = 1;
        sigma = 0;
    end
    Q = U(:,1:svp)*diag(sigma)*V(:,1:svp)';
    
    %7 update Y1{k},Y2,Y3，W
    for k=1:K
    Y1{k}=Y1{k}+mu1*(X{k}-X{k}*S-X{k}*Z{k}-E1{k});
    end
    Y2=Y2+mu2*(S-S*C-E);
    w = w + rho1*(h - g); 
    Y3=Y3+rho2*(S-Q);
    
    %record the iteration information
    history.objval(iter+1)   =  objV;

    %% coverge condition
    Isconverg = 1;
    for k=1:K 
        if (norm(X{k}-X{k}*S-X{k}*Z{k}-E1{k},inf)>epson)
            history.norm_1 = norm(X{k}-X{k}*S-X{k}*Z{k}-E1{k},inf);
%             fprintf('    norm_1 %7.10f    ', history.norm_1);
            Isconverg = 0;
        end
    end

         if (norm(S-S*C-E,inf)>epson) 
            history.norm_2 = norm(S-S*C-E,inf);
%             fprintf('\n    norm_2 %7.10f    \n', history.norm_2);
            Isconverg = 0;
         end

        for a = 1:2
        G{a} = G_tensor(:,:,a);
        W_tensor = reshape(w, sX);
        W{a} = W_tensor(:,:,a);
        end
        
        if (norm(S-G{1},inf)>epson) 
            history.norm_S_G = norm(S-G{1},inf);
%             fprintf('   norm_S_G %7.10f    ', history.norm_S_G);
            Isconverg = 0;
        end
        if (norm(C-G{2},inf)>epson) 
            history.norm_C_G = norm(C-G{2},inf);
%             fprintf('   norm_C_G %7.10f    \n', history.norm_C_G);
            Isconverg = 0;
        end
        if (norm(S-Q,inf)>epson) 
            history.norm_S_Q = norm(S-Q,inf);
%             fprintf('   norm_S_Q %7.10f    \n', history.norm_S_Q);
            Isconverg = 0;
        end
   
    if (iter>200)
        Isconverg  = 1;
    end
    iter = iter + 1;
    mu1 = min(mu1*pho_mu1, max_mu1);
    mu2 = min(mu2*pho_mu2, max_mu2);
    rho1 = min(rho1*pho_rho1, max_rho1);
    rho2 = min(rho2*pho_rho2, max_rho2);
end
S1 = 0;
for k=1:K
    S1 = S1 + abs(Z{k})+abs(Z{k}');
end
    S1 = S1 + abs(C)+abs(C');
C1 = SpectralClustering(S1,cls_num);
ACC = Accuracy(C1,double(gt));
fprintf('lambda1 %.4f lambda2 %.4f lambda3 %.4f  ACC %.3f  \n', lambda1,lambda2,lambda3,ACC);
toc;




